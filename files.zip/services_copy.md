# Services Page Copy — Velvet Crumbs Cafe, Kottayam

*Generated using Prompt 2 (02_services_prompt.txt) | Tool: Claude*

---

## Kerala Filter Coffee
**Category: Coffee**

Brewed the slow way, served the right way. Our filter coffee uses single-estate beans from Wayanad — bold, aromatic, and unapologetically Kerala.

*Some mornings just need the real thing.*

---

## Velvet Cold Brew
**Category: Coffee**

Steeped overnight, silky smooth. Our signature cold brew is Kottayam in a glass — earthy, cool, and made for humid afternoons.

*One sip and you'll never go back to instant.*

---

## Fresh-Baked Pastries
**Category: Bakes**

Every pastry at Velvet Crumbs is baked before sunrise. From flaky croissants to cardamom-spiced buns — warm, honest, and gone by noon.

*The kind of baking that makes you set an early alarm.*

---

## Kerala Breakfast Plate
**Category: Food**

Soft puttu, golden banana chips, egg roast — the full Kerala morning, served with love until midday.

*Because the best mornings start with food that feels like home.*

---

## Study & Work Nooks
**Category: Experience**

Quiet corners, fast WiFi, and bottomless filter coffee refills. The perfect escape for students and freelancers in Kottayam.

*Great ideas have been born here. Yours could be next.*

---

## Private Bookings
**Category: Events**

Celebrate birthdays, book clubs, or small gatherings in our cozy reserved section. We handle the food — you bring the moment.

*Every good story deserves the right setting.*

---

## Prompt Used

> Write service descriptions for "Velvet Crumbs" cafe in Kottayam, Kerala.
> For each service: name, category badge, 2-sentence description, emotional hook.
> Tone: Cozy, proud, local.

---

*Ready to publish. Each block maps to one service card on the website.*
