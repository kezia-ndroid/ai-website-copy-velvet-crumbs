# Homepage Copy — Velvet Crumbs Cafe, Kottayam

*Generated using Prompt 1 (01_homepage_prompt.txt) | Tool: Claude*

---

## Headline

**Every Crumb Tells a Story.**

---

## Sub-Headline

Kottayam's most-loved cafe — where slow mornings, handmade pastries, and real Kerala coffee come together under one warm roof.

---

## Intro Paragraph

At Velvet Crumbs, we believe the best conversations happen over a good cup. Walk in as a stranger, leave as a regular. That's the Velvet Crumbs promise.

---

## About Section

Velvet Crumbs was born from a simple idea — Kottayam needed a cafe that felt like home. Nestled in the heart of the city, we bake everything fresh every morning, brew coffee from Kerala's finest estates, and serve food made with the kind of care your grandmother would approve of. No shortcuts. No strangers. Just good food and better company.

---

## Prompt Used

> You are a professional copywriter specializing in local businesses.
> Write homepage copy for "Velvet Crumbs", a cafe in Kottayam, Kerala.
> Tone: Warm, friendly, local.
> Avoid: Clichés like "best cafe" or "quality service".

---

*Ready to publish. Can be pasted directly into Framer AI, Lovable, or any website builder.*
