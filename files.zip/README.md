# AI Website Copy Generator — Velvet Crumbs Cafe
### Prompt Engineering Task | Future Interns 2026

---

## Business Chosen

**Velvet Crumbs Cafe**  
Location: Kottayam, Kerala, India  
Type: Local cafe — coffee, bakes, Kerala breakfast, coworking-friendly  
Target Audience: Students, working professionals, families, and locals

---

## What This Project Does

This project uses structured AI prompts to generate conversion-focused website copy for **Velvet Crumbs Cafe** — a real local business in Kottayam, Kerala.

The copy covers:
- Homepage headline, sub-headline, and intro paragraph
- Services page with 6 detailed descriptions
- 4 CTA sections (primary, trust-builder, urgency, footer)
- Tone-adapted, location-specific language throughout

---

## Tools Used

| Tool     | Purpose                          |
|----------|----------------------------------|
| Claude   | Primary copy generation          |
| ChatGPT  | Prompt testing and variations    |
| Gemini   | Tone adaptation experiments      |
| GitHub   | Version control and portfolio    |

---

## Repository Structure

```
ai-website-copy-velvet-crumbs/
├── README.md
├── prompts/
│   ├── 01_homepage_prompt.txt
│   ├── 02_services_prompt.txt
│   ├── 03_cta_prompt.txt
│   └── 04_tone_adapter_prompt.txt
└── outputs/
    ├── homepage_copy.md
    ├── services_copy.md
    └── cta_sections.md
```

---

## Prompt Logic

Each prompt is built around 5 elements:

| # | Element | What it does |
|---|---------|--------------|
| 1 | **ROLE** | Tells the AI who it is |
| 2 | **CONTEXT** | Business name, location, type |
| 3 | **OUTPUT** | Exactly what sections to produce |
| 4 | **TONE** | How the writing should feel |
| 5 | **FORMAT** | How to structure the response |

This 5-part structure makes every prompt **reusable** — just swap the business name, location, and tone for any new client.

---

## How to Reuse for Other Businesses

1. Open any file inside `/prompts/`
2. Replace `[BUSINESS NAME]`, `[LOCATION]`, and `[TONE]`
3. Paste into Claude, ChatGPT, or Gemini
4. Save the output inside `/outputs/`
5. Repeat for each section

This system can generate a full website copy set for any local business in under 10 minutes.

---

## Author

Created by: [Your Name]  
Program: Future Interns — Prompt Engineering Task 2026  
LinkedIn: [your-linkedin-url]

---

*This project is portfolio-ready and can be shown to real business owners as a paid service offering.*
