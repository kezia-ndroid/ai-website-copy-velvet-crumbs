# CTA Sections — Velvet Crumbs Cafe, Kottayam

*Generated using Prompt 3 (03_cta_prompt.txt) | Tool: Claude*

---

## CTA 1 — Primary CTA

**Your perfect Kottayam morning starts at Velvet Crumbs.**

Open 7 AM every day. Walk in, find your corner, and let us take care of the rest. Because you deserve a morning that doesn't rush you.

> Button 1: Find Us in Kottayam
> Button 2: Reserve a Table

---

## CTA 2 — Trust Builder

**Why Kottayam loves us**

- ⭐ Rated 4.9/5 by 500+ Kottayam locals
- 🏡 Proudly family-run since 2021
- 🌿 100% locally sourced ingredients
- ☕ Kerala-grown beans in every single cup
- 🍞 Everything baked fresh daily, no exceptions
- 📍 Easy to find in the heart of Kottayam

---

## CTA 3 — Urgency + Location

Just 3 minutes from Kottayam Railway Station. Come before 9 AM and get our Morning Special — filter coffee + fresh-baked cardamom bun for ₹65. Simple pleasures, every single day.

---

## CTA 4 — Footer CTA

*Life is short. Eat the good pastry. Come to Velvet Crumbs.*

---

## Prompt Used

> Write 4 CTA sections for "Velvet Crumbs" cafe in Kottayam, Kerala.
> CTA 1: primary visit/book CTA. CTA 2: trust bullets. CTA 3: urgency + location.
> CTA 4: footer closing line. Tone: Friendly, confident, local.

---

*Ready to publish. Place CTA 1 above the fold, CTA 2 mid-page, CTA 3 near the bottom, CTA 4 in the footer.*
